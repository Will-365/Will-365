function login() {
    // Get the values of email and password from the form
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Perform validation if needed

    // Simulate login process (replace with actual login functionality)
    alert("Welcome to AirPods Rwanda!\nEmail: " + email + "\nPassword: " + password);
}

function redirectToCreateAccount() {
    // Redirect to the create account page (replace with actual URL)
    window.location.href = "create_account.html";
}
