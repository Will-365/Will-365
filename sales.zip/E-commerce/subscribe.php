<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newsletter";
$port = 3310;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["email"]) && !empty($_POST["email"])) {
    $email = $conn->real_escape_string($_POST["email"]);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query = "INSERT INTO subscribers (Email) VALUES ('$email')";

        if ($conn->query($query) === TRUE) {
            header("Location: home.html.html?subscribed=true");
            exit;
        } else {
            header("Location: home.html.html?error=true");
            exit;
        }
    } else {
        header("Location: home.html.html?invalid_email=true");
        exit;
    }
}

header("Location: home.html.html");
exit;

?>
