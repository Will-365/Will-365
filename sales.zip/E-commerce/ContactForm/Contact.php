<?php
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $Email = $_POST['Email'];
    $Phone = $_POST['Phone'];
    $country = $_POST['country'];
    $subject = $_POST['message'];

    //Database connection
    $conn = new mysqli('localhost','root','', 'test');
    if($conn->connect_error){
        die('Connection Failed : '. $conn->connect_error);
    }
    else{
        $stmt = $conn->prepare("insert into information (firstName, lastName, Email, Phone, country, message) values (?,?,?,?,?,?) ");
        $stmt->bind_param("ssssss",$firstName, $lastName, $Email, $Phone, $country, $message);
        $stmt->execute();
        echo "Information received Successfully";
        $st->close();
        $conn->close();
    }
?>