let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let list = document.querySelector('.list');
let listCard = document.querySelector('.listCard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', ()=>{
    body.classList.add('active');
})
closeShopping.addEventListener('click', ()=>{
    body.classList.remove('active');
})

let products = [
    {
        id: 1,
        name: ' Apple Airpod pro',
        image: 'sony.jpg',
        price: 220000
    },
    {
        id: 2,
        name: 'Beat solo pro',
        image: 'bose.jpg',
        price:  300000
    },
    {
        id: 3,
        name: 'JBL TUNE 230NC',
        image: 'focal.jpg',
        price:  280000
    },
    {
        id: 4,
        name: 'ON-air-headphone',
        image: 'Airpodmax.jpg',
        price:  350000
    },
    {
        id: 5,
        name: 'Clip-on-headphone',
        image: 'Airpods 2.jpg',
        price:  150000
    },
    {
        id: 6,
        name: 'Beat studio pro',
        image: 'JBL.jpg',
        price:  300000
    }
   
];
let listCards  = [];
function initApp(){
    products.forEach((value, key) =>{
        let newDiv = document.createElement('div');
        newDiv.classList.add('item');
        newDiv.innerHTML = `
            <img src="image/${value.image}">
            <div class="title">RWF ${value.id} - ${value.name}</div>
            <div class="price">RWF ${value.price.toLocaleString('rw', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div>
            <button onclick="addToCard(${key})">Add To Card</button>`;
        list.appendChild(newDiv);
    })
}
initApp();
function addToCard(key){
    if(listCards[key] == null){
        // copy product form list to list card
        listCards[key] = JSON.parse(JSON.stringify(products[key]));
        listCards[key].quantity = 1;
    }
    reloadCard();
}
function reloadCard(){
    listCard.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    listCards.forEach((value, key)=>{
        totalPrice = totalPrice + value.price;
        count = count + value.quantity;
        if(value != null){
            let newDiv = document.createElement('li');
            newDiv.innerHTML = `
                <div><img src="image/${value.image}"/></div>
                <div>${value.name}</div>
                <div>RWF${value.price.toLocaleString()}</div>
                <div>
                    <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count">${value.quantity}</div>
                    <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>`;
                listCard.appendChild(newDiv);
        }
    })
    total.innerText = 'RWF' + totalPrice.toLocaleString();
    quantity.innerText = count;
}
function changeQuantity(key, quantity){
    if(quantity == 0){
        delete listCards[key];
    }else{
        listCards[key].quantity = quantity;
        listCards[key].price = quantity * products[key].price;
    }
    reloadCard();
}



document.addEventListener('DOMContentLoaded', function() {
    // Get radio buttons for payment methods
    const visaRadio = document.getElementById("visa");
    const mastercardRadio = document.getElementById("mastercard");
    const airtelRadio = document.getElementById("Airtel_Money");
    const momoRadio = document.getElementById("MOMO");

    // Get payment details container
    const paymentDetails = document.querySelector(".content");

    // Get Visa, Mastercard, MTN MOMO, and Airtel Money payment forms
    const visaPaymentForm = document.getElementById("visaPaymentForm");
    const mastercardPaymentForm = document.getElementById("mastercardPaymentForm");
    const mtnMomoPaymentForm = document.getElementById("mtnMomoPaymentForm");
    const airtelMoneyPaymentForm = document.getElementById("airtelMoneyPaymentForm");

    // Function to show payment details based on selected payment method
    function showPaymentDetails() {
        // Hide all payment details initially
        paymentDetails.style.display = "none";

        // Check which payment method is selected and show corresponding details
        if (visaRadio.checked || mastercardRadio.checked || airtelRadio.checked || momoRadio.checked) {
            // Show card-related fields
            paymentDetails.style.display = "block";

            // Hide all payment forms initially
            visaPaymentForm.style.display = "none";
            mastercardPaymentForm.style.display = "none";
            mtnMomoPaymentForm.style.display = "none";
            airtelMoneyPaymentForm.style.display = "none";

            // Show respective payment form based on selection
            if (visaRadio.checked) {
                visaPaymentForm.style.display = "block";
            } else if (mastercardRadio.checked) {
                mastercardPaymentForm.style.display = "block";
            } else if (airtelRadio.checked) {
                airtelMoneyPaymentForm.style.display = "block";
            } else if (momoRadio.checked) {
                mtnMomoPaymentForm.style.display = "block";
            }
            
            // Scroll to payment details section
            paymentDetails.scrollIntoView({ behavior: 'smooth' });

            // Close payment method section
            paymentDetails.style.display = 'none';
        } else {
            // If no payment method is selected, show product list
            document.querySelector('.list').style.display = 'block';
        }
    }

    // Add event listeners to radio buttons
    visaRadio.addEventListener("change", showPaymentDetails);
    mastercardRadio.addEventListener("change", showPaymentDetails);
    airtelRadio.addEventListener("change", showPaymentDetails);
    momoRadio.addEventListener("change", showPaymentDetails);

    // Add event listener to the "Pay" button
    document.querySelector('.payButton').addEventListener('click', function() {
        // Check if there are any products in the card
        const productList = document.querySelector('.listCard');
        const products = productList.getElementsByTagName('li');

        if (products.length === 0) {
            // If no products, display a message
            alert("Sorry, your card is empty");
        } else {
            // Show payment method section when the "Pay" button is clicked
            paymentDetails.style.display = 'block';
            paymentDetails.scrollIntoView({ behavior: 'smooth' });
        }
    });
    
    // Add event listener to the "Close" button
    document.querySelector('.closeShopping').addEventListener('click', function() {
        // Hide payment method section when the "Close" button is clicked
        paymentDetails.style.display = 'none';
        document.getElementById('mtnMomoPaymentForm').style.display = 'none';
        document.getElementById('visaPaymentForm').style.display = 'none';
        document.getElementById('airtelMoneyPaymentForm').style.display = 'none';
        document.getElementById('mastercardPaymentForm').style.display = 'none';
        
    });

    // Add event listener to the "Back to Products" button
    document.querySelector('.scrollToProducts').addEventListener('click', function() {
        // Hide payment method section
        paymentDetails.style.display = 'none';
        
        
        // Scroll back to the product list
        document.querySelector('.list').scrollIntoView({ behavior: 'smooth' });
        document.getElementById('mtnMomoPaymentForm').style.display = 'none';
        document.getElementById('visaPaymentForm').style.display = 'none';
        document.getElementById('airtelMoneyPaymentForm').style.display = 'none';
        document.getElementById('mastercardPaymentForm').style.display = 'none';
        
    });

    
   // Add event listener to the "Proceed to checkout" button for Airtel Money Payment Form
document.getElementById('airtelCheckout').addEventListener('click', function(event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Get all required input fields in the Airtel Money payment form
    const requiredInputs = document.querySelectorAll('#airtelMoneyPaymentForm input[required]');

    // Find the first empty required input field
    let unfilledField = null;
    for (const input of requiredInputs) {
        if (input.value.trim() === '') {
            unfilledField = input;
            break;
        }
    }

    // If an empty required field is found, focus on it
    if (unfilledField !== null) {
        unfilledField.focus();
    } else {
        // If all required fields are filled out, submit the form
        // Here you can add your code to handle form submission or display a message
        alert('Thank you for your purchase!');
        document.querySelector('.listCard').innerHTML = '';
    }
});
// Add event listener to the "Proceed to checkout" button for visa Payment Form
document.getElementById('visaCheckout').addEventListener('click', function(event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Get all required input fields in the visa payment form
    const requiredInputs = document.querySelectorAll('#visaPaymentForm input[required]');

    // Find the first empty required input field
    let unfilledField = null;
    for (const input of requiredInputs) {
        if (input.value.trim() === '') {
            unfilledField = input;
            break;
        }
    }

    // If an empty required field is found, focus on it
    if (unfilledField !== null) {
        unfilledField.focus();
    } else {
        // If all required fields are filled out, submit the form
        // Here you can add your code to handle form submission or display a message
        alert('Thank you for your purchase!');
        document.querySelector('.listCard').innerHTML = '';
    }
});

// Add event listener to the "Proceed to checkout" button for momo Payment Form
document.getElementById('momoCheckout').addEventListener('click', function(event) {
    // Prevent the form from submitting
    event.preventDefault();

    // Get all required input fields in the momo payment form
    const requiredInputs = document.querySelectorAll('#mtnMomoPaymentForm input[required]');

    // Find the first empty required input field
    let unfilledField = null;
    for (const input of requiredInputs) {
        if (input.value.trim() === '') {
            unfilledField = input;
            break;
        }
    }

    // If an empty required field is found, focus on it
    if (unfilledField !== null) {
        unfilledField.focus();
    } else {
        // If all required fields are filled out, submit the form
        // Here you can add your code to handle form submission or display a message
        alert('Thank you for your purchase!');
        document.querySelector('.listCard').innerHTML = '';
    }
});


    
});




